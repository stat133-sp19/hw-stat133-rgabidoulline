## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
library(binomial)

## ------------------------------------------------------------------------
# k = 2 successes in n = 5 trials
bin_choose(n = 5, k = 2)

## ------------------------------------------------------------------------
# probability of getting 2 successes in 5 trials
bin_probability(success = 2, trials = 5, prob = 0.5)

## ------------------------------------------------------------------------
# binomial probability distribution
dist = bin_distribution(trials = 5, prob = 0.5)
dist

## ------------------------------------------------------------------------
# plot method
plot(dist)

## ------------------------------------------------------------------------
# binomial cumulative distribution
cumdist = bin_cumulative(trials = 5, prob = 0.5)
cumdist

## ------------------------------------------------------------------------
# plot method
plot(cumdist)

## ------------------------------------------------------------------------
# binomial random variable
X = bin_variable(trials = 10, p = 0.3)
X

## ------------------------------------------------------------------------
# summary method
summary(X)

## ------------------------------------------------------------------------
# mean of distribution with trials = 10 and prob = 0.3
bin_mean(10, 0.3)

## ------------------------------------------------------------------------
# variance of distribution with trials = 10 and prob = 0.3
bin_variance(10, 0.3)

## ------------------------------------------------------------------------
# mode of distribution with trials = 10 and prob = 0.3
bin_mode(10, 0.3)

## ------------------------------------------------------------------------
# skewness of distribution with trials = 10 and prob = 0.3
bin_skewness(10, 0.3)

## ------------------------------------------------------------------------
# kurtosis of distribution with trials = 10 and prob = 0.3
bin_kurtosis(10, 0.3)

